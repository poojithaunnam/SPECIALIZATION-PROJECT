import React from "react";

const Contact =() =>{
    return(
        <div>
 
 
 <div>
 Location: Akshya Nagar 1st Block 1st Cross, Rammurthy nagar, Bangalore-560016
 </div>
 <br>
 </br>
<div>
Phone number:9875346243
</div>
<br>
</br>
<div>
Email-address:mobilestore@gmail.com
</div>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>


 
        </div>
    )
   
};
export default Contact;