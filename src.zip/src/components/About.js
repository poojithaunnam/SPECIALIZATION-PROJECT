import React from "react";

const About =() =>{
    return(
        <div>
            <h2>
            Mobile store
            </h2>
 
<p>
            Mobile store   may be a roaring and growing business at the center of the movable sector that serves numerous customers through our retail, wholesale and online activities. 
            For retail customers online shopping  has become a saw for mobiles through our four shops in Bangalore .
            <br></br>
            Currently established for over a decade, we have a tendency to extended into wholesale offer and distribution concerning four years past and have conjointly developed refined, easy websites to sell mobiles to new customers everyplace.<br></br>
            Mobile store's  success thus far has primarily been designed on our dedication to providing a superb clientservice, treating every client as special and going the additional mile, whenever necessary, to search out the correct product and services.
        </p>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
<br>
</br>
        </div>
        


    )
    
    
};
export default About;